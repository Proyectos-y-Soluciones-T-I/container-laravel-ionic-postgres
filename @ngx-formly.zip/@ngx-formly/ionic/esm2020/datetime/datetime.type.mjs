import { Component, ChangeDetectionStrategy, ViewChild, ViewEncapsulation } from '@angular/core';
import { IonDatetime } from '@ionic/angular';
import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
import * as i1 from "@ionic/angular";
import * as i2 from "@angular/forms";
import * as i3 from "@ngx-formly/ionic/form-field";
import * as i4 from "@angular/common";
export class FormlyFieldDatetime extends FieldType {
    constructor() {
        super(...arguments);
        this.isOpen = false;
        this.defaultOptions = {
            props: {
                presentation: 'month-year',
            },
        };
    }
    displayFormat() {
        if (this.props.displayFormat) {
            return this.props.displayFormat;
        }
        switch (this.props.presentation) {
            case 'date-time':
            case 'time-date':
                return 'short';
            case 'time':
                return 'shortTime';
            case 'month':
                return 'MMMM';
            case 'month-year':
                return 'MMMM, y';
            case 'year':
                return 'y';
            case 'date':
                return 'mediumDate';
        }
    }
    confirm() {
        this.datetime?.confirm();
        this.close();
    }
    reset() {
        this.datetime?.reset();
        this.close();
    }
    close() {
        this.isOpen = false;
        this.formControl.markAsTouched();
    }
}
FormlyFieldDatetime.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: FormlyFieldDatetime, deps: null, target: i0.ɵɵFactoryTarget.Component });
FormlyFieldDatetime.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.3.12", type: FormlyFieldDatetime, selector: "formly-field-ion-datetime", viewQueries: [{ propertyName: "datetime", first: true, predicate: IonDatetime, descendants: true }], usesInheritance: true, ngImport: i0, template: `
    <ion-item [button]="true" [detail]="false" (click)="isOpen = true">
      <ion-label>
        {{ formControl.value ? (formControl.value | date : displayFormat()) : props.placeholder }}
      </ion-label>
    </ion-item>
    <ion-modal
      [isOpen]="isOpen"
      (didDismiss)="close()"
      [cssClass]="'ion-datetime-modal ion-datetime-modal-' + props.presentation"
    >
      <ng-template>
        <ion-datetime
          [locale]="props.locale"
          [presentation]="props.presentation"
          [cancelText]="props.cancelText"
          [dayValues]="props.dayValues"
          [doneText]="props.doneText"
          [hourValues]="props.hourValues"
          [minuteValues]="props.minuteValues"
          [monthValues]="props.monthValues"
          [yearValues]="props.yearValues"
          [min]="props.minDate ? props.minDate : props.min"
          [max]="props.maxDate ? props.maxDate : props.max"
          [formControl]="formControl"
          [ionFormlyAttributes]="field"
        >
          <ion-buttons slot="buttons">
            <ion-button (click)="reset()">{{ props.cancelText || 'Cancel' }}</ion-button>
            <ion-button (click)="confirm()">{{ props.doneText || 'Done' }}</ion-button>
          </ion-buttons>
        </ion-datetime>
      </ng-template>
    </ion-modal>
  `, isInline: true, styles: [".ion-datetime-modal{--width: 310px;--border-radius: 8px}.ion-datetime-modal.ion-datetime-modal-time-date{--height: 440px}.ion-datetime-modal.ion-datetime-modal-date{--height: 390px}.ion-datetime-modal.ion-datetime-modal-time{--height: 260px}\n"], components: [{ type: i1.IonItem, selector: "ion-item", inputs: ["button", "color", "counter", "counterFormatter", "detail", "detailIcon", "disabled", "download", "fill", "href", "lines", "mode", "rel", "routerAnimation", "routerDirection", "shape", "target", "type"] }, { type: i1.IonLabel, selector: "ion-label", inputs: ["color", "mode", "position"] }, { type: i1.IonModal, selector: "ion-modal", inputs: ["animated", "keepContentsMounted", "backdropBreakpoint", "backdropDismiss", "breakpoints", "canDismiss", "cssClass", "enterAnimation", "event", "handle", "handleBehavior", "initialBreakpoint", "isOpen", "keyboardClose", "leaveAnimation", "mode", "presentingElement", "showBackdrop", "swipeToClose", "translucent", "trigger"] }, { type: i1.IonDatetime, selector: "ion-datetime", inputs: ["cancelText", "clearText", "color", "dayValues", "disabled", "doneText", "firstDayOfWeek", "hourCycle", "hourValues", "isDateEnabled", "locale", "max", "min", "minuteValues", "mode", "monthValues", "multiple", "name", "preferWheel", "presentation", "readonly", "showClearButton", "showDefaultButtons", "showDefaultTimeLabel", "showDefaultTitle", "size", "titleSelectedDatesFormatter", "value", "yearValues"] }, { type: i1.IonButtons, selector: "ion-buttons", inputs: ["collapse"] }, { type: i1.IonButton, selector: "ion-button", inputs: ["buttonType", "color", "disabled", "download", "expand", "fill", "form", "href", "mode", "rel", "routerAnimation", "routerDirection", "shape", "size", "strong", "target", "type"] }], directives: [{ type: i1.SelectValueAccessor, selector: "ion-range, ion-select, ion-radio-group, ion-segment, ion-datetime" }, { type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { type: i3.ɵIonFormlyAttributes, selector: "[ionFormlyAttributes]", inputs: ["ionFormlyAttributes"] }], pipes: { "date": i4.DatePipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: FormlyFieldDatetime, decorators: [{
            type: Component,
            args: [{ selector: 'formly-field-ion-datetime', template: `
    <ion-item [button]="true" [detail]="false" (click)="isOpen = true">
      <ion-label>
        {{ formControl.value ? (formControl.value | date : displayFormat()) : props.placeholder }}
      </ion-label>
    </ion-item>
    <ion-modal
      [isOpen]="isOpen"
      (didDismiss)="close()"
      [cssClass]="'ion-datetime-modal ion-datetime-modal-' + props.presentation"
    >
      <ng-template>
        <ion-datetime
          [locale]="props.locale"
          [presentation]="props.presentation"
          [cancelText]="props.cancelText"
          [dayValues]="props.dayValues"
          [doneText]="props.doneText"
          [hourValues]="props.hourValues"
          [minuteValues]="props.minuteValues"
          [monthValues]="props.monthValues"
          [yearValues]="props.yearValues"
          [min]="props.minDate ? props.minDate : props.min"
          [max]="props.maxDate ? props.maxDate : props.max"
          [formControl]="formControl"
          [ionFormlyAttributes]="field"
        >
          <ion-buttons slot="buttons">
            <ion-button (click)="reset()">{{ props.cancelText || 'Cancel' }}</ion-button>
            <ion-button (click)="confirm()">{{ props.doneText || 'Done' }}</ion-button>
          </ion-buttons>
        </ion-datetime>
      </ng-template>
    </ion-modal>
  `, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, styles: [".ion-datetime-modal{--width: 310px;--border-radius: 8px}.ion-datetime-modal.ion-datetime-modal-time-date{--height: 440px}.ion-datetime-modal.ion-datetime-modal-date{--height: 390px}.ion-datetime-modal.ion-datetime-modal-time{--height: 260px}\n"] }]
        }], propDecorators: { datetime: [{
                type: ViewChild,
                args: [IonDatetime]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZXRpbWUudHlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy91aS9pb25pYy9kYXRldGltZS9zcmMvZGF0ZXRpbWUudHlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLHVCQUF1QixFQUFFLFNBQVMsRUFBRSxpQkFBaUIsRUFBUSxNQUFNLGVBQWUsQ0FBQztBQUN2RyxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDN0MsT0FBTyxFQUFFLFNBQVMsRUFBc0MsTUFBTSxrQkFBa0IsQ0FBQzs7Ozs7O0FBK0RqRixNQUFNLE9BQU8sbUJBQW9CLFNBQVEsU0FBeUM7SUF6Q2xGOztRQTJDRSxXQUFNLEdBQUcsS0FBSyxDQUFDO1FBRU4sbUJBQWMsR0FBRztZQUN4QixLQUFLLEVBQUU7Z0JBQ0wsWUFBWSxFQUFFLFlBQXFCO2FBQ3BDO1NBQ0YsQ0FBQztLQXNDSDtJQXBDQyxhQUFhO1FBQ1gsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRTtZQUM1QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDO1NBQ2pDO1FBRUQsUUFBUSxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRTtZQUMvQixLQUFLLFdBQVcsQ0FBQztZQUNqQixLQUFLLFdBQVc7Z0JBQ2QsT0FBTyxPQUFPLENBQUM7WUFDakIsS0FBSyxNQUFNO2dCQUNULE9BQU8sV0FBVyxDQUFDO1lBQ3JCLEtBQUssT0FBTztnQkFDVixPQUFPLE1BQU0sQ0FBQztZQUNoQixLQUFLLFlBQVk7Z0JBQ2YsT0FBTyxTQUFTLENBQUM7WUFDbkIsS0FBSyxNQUFNO2dCQUNULE9BQU8sR0FBRyxDQUFDO1lBQ2IsS0FBSyxNQUFNO2dCQUNULE9BQU8sWUFBWSxDQUFDO1NBQ3ZCO0lBQ0gsQ0FBQztJQUVELE9BQU87UUFDTCxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNmLENBQUM7SUFFRCxLQUFLO1FBQ0gsSUFBSSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsQ0FBQztRQUN2QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDZixDQUFDO0lBRUQsS0FBSztRQUNILElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3BCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDbkMsQ0FBQzs7aUhBN0NVLG1CQUFtQjtxR0FBbkIsbUJBQW1CLDJHQUNuQixXQUFXLHVFQXhDWjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQWtDVDs0RkFLVSxtQkFBbUI7a0JBekMvQixTQUFTOytCQUNFLDJCQUEyQixZQUMzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQWtDVCxtQkFDZ0IsdUJBQXVCLENBQUMsTUFBTSxpQkFFaEMsaUJBQWlCLENBQUMsSUFBSTs4QkFHYixRQUFRO3NCQUEvQixTQUFTO3VCQUFDLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LCBWaWV3Q2hpbGQsIFZpZXdFbmNhcHN1bGF0aW9uLCBUeXBlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJb25EYXRldGltZSB9IGZyb20gJ0Bpb25pYy9hbmd1bGFyJztcbmltcG9ydCB7IEZpZWxkVHlwZSwgRmllbGRUeXBlQ29uZmlnLCBGb3JtbHlGaWVsZENvbmZpZyB9IGZyb20gJ0BuZ3gtZm9ybWx5L2NvcmUnO1xuaW1wb3J0IHsgRm9ybWx5RmllbGRQcm9wcyB9IGZyb20gJ0BuZ3gtZm9ybWx5L2lvbmljL2Zvcm0tZmllbGQnO1xuXG5pbnRlcmZhY2UgRGF0ZXRpbWVQcm9wcyBleHRlbmRzIEZvcm1seUZpZWxkUHJvcHMge1xuICBwcmVzZW50YXRpb24/OiAnZGF0ZScgfCAnZGF0ZS10aW1lJyB8ICdtb250aCcgfCAnbW9udGgteWVhcicgfCAndGltZScgfCAndGltZS1kYXRlJyB8ICd5ZWFyJztcbiAgbG9jYWxlPzogYW55O1xuICBjYW5jZWxUZXh0Pzogc3RyaW5nO1xuICBkb25lVGV4dD86IHN0cmluZztcbiAgZGF5VmFsdWVzPzogbnVtYmVyIHwgbnVtYmVyW10gfCBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIGhvdXJWYWx1ZXM/OiBudW1iZXIgfCBudW1iZXJbXSB8IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgbWludXRlVmFsdWVzPzogbnVtYmVyIHwgbnVtYmVyW10gfCBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIG1vbnRoVmFsdWVzPzogbnVtYmVyIHwgbnVtYmVyW10gfCBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIHllYXJWYWx1ZXM/OiBudW1iZXIgfCBudW1iZXJbXSB8IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgbWluRGF0ZT86IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgbWF4RGF0ZT86IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgZGlzcGxheUZvcm1hdD86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBGb3JtbHlEYXRldGltZUZpZWxkQ29uZmlnIGV4dGVuZHMgRm9ybWx5RmllbGRDb25maWc8RGF0ZXRpbWVQcm9wcz4ge1xuICB0eXBlOiAnZGF0ZXRpbWUnIHwgVHlwZTxGb3JtbHlGaWVsZERhdGV0aW1lPjtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnZm9ybWx5LWZpZWxkLWlvbi1kYXRldGltZScsXG4gIHRlbXBsYXRlOiBgXG4gICAgPGlvbi1pdGVtIFtidXR0b25dPVwidHJ1ZVwiIFtkZXRhaWxdPVwiZmFsc2VcIiAoY2xpY2spPVwiaXNPcGVuID0gdHJ1ZVwiPlxuICAgICAgPGlvbi1sYWJlbD5cbiAgICAgICAge3sgZm9ybUNvbnRyb2wudmFsdWUgPyAoZm9ybUNvbnRyb2wudmFsdWUgfCBkYXRlIDogZGlzcGxheUZvcm1hdCgpKSA6IHByb3BzLnBsYWNlaG9sZGVyIH19XG4gICAgICA8L2lvbi1sYWJlbD5cbiAgICA8L2lvbi1pdGVtPlxuICAgIDxpb24tbW9kYWxcbiAgICAgIFtpc09wZW5dPVwiaXNPcGVuXCJcbiAgICAgIChkaWREaXNtaXNzKT1cImNsb3NlKClcIlxuICAgICAgW2Nzc0NsYXNzXT1cIidpb24tZGF0ZXRpbWUtbW9kYWwgaW9uLWRhdGV0aW1lLW1vZGFsLScgKyBwcm9wcy5wcmVzZW50YXRpb25cIlxuICAgID5cbiAgICAgIDxuZy10ZW1wbGF0ZT5cbiAgICAgICAgPGlvbi1kYXRldGltZVxuICAgICAgICAgIFtsb2NhbGVdPVwicHJvcHMubG9jYWxlXCJcbiAgICAgICAgICBbcHJlc2VudGF0aW9uXT1cInByb3BzLnByZXNlbnRhdGlvblwiXG4gICAgICAgICAgW2NhbmNlbFRleHRdPVwicHJvcHMuY2FuY2VsVGV4dFwiXG4gICAgICAgICAgW2RheVZhbHVlc109XCJwcm9wcy5kYXlWYWx1ZXNcIlxuICAgICAgICAgIFtkb25lVGV4dF09XCJwcm9wcy5kb25lVGV4dFwiXG4gICAgICAgICAgW2hvdXJWYWx1ZXNdPVwicHJvcHMuaG91clZhbHVlc1wiXG4gICAgICAgICAgW21pbnV0ZVZhbHVlc109XCJwcm9wcy5taW51dGVWYWx1ZXNcIlxuICAgICAgICAgIFttb250aFZhbHVlc109XCJwcm9wcy5tb250aFZhbHVlc1wiXG4gICAgICAgICAgW3llYXJWYWx1ZXNdPVwicHJvcHMueWVhclZhbHVlc1wiXG4gICAgICAgICAgW21pbl09XCJwcm9wcy5taW5EYXRlID8gcHJvcHMubWluRGF0ZSA6IHByb3BzLm1pblwiXG4gICAgICAgICAgW21heF09XCJwcm9wcy5tYXhEYXRlID8gcHJvcHMubWF4RGF0ZSA6IHByb3BzLm1heFwiXG4gICAgICAgICAgW2Zvcm1Db250cm9sXT1cImZvcm1Db250cm9sXCJcbiAgICAgICAgICBbaW9uRm9ybWx5QXR0cmlidXRlc109XCJmaWVsZFwiXG4gICAgICAgID5cbiAgICAgICAgICA8aW9uLWJ1dHRvbnMgc2xvdD1cImJ1dHRvbnNcIj5cbiAgICAgICAgICAgIDxpb24tYnV0dG9uIChjbGljayk9XCJyZXNldCgpXCI+e3sgcHJvcHMuY2FuY2VsVGV4dCB8fCAnQ2FuY2VsJyB9fTwvaW9uLWJ1dHRvbj5cbiAgICAgICAgICAgIDxpb24tYnV0dG9uIChjbGljayk9XCJjb25maXJtKClcIj57eyBwcm9wcy5kb25lVGV4dCB8fCAnRG9uZScgfX08L2lvbi1idXR0b24+XG4gICAgICAgICAgPC9pb24tYnV0dG9ucz5cbiAgICAgICAgPC9pb24tZGF0ZXRpbWU+XG4gICAgICA8L25nLXRlbXBsYXRlPlxuICAgIDwvaW9uLW1vZGFsPlxuICBgLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbiAgc3R5bGVVcmxzOiBbJy4vZGF0dGltZS50eXBlLnNjc3MnXSxcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcbn0pXG5leHBvcnQgY2xhc3MgRm9ybWx5RmllbGREYXRldGltZSBleHRlbmRzIEZpZWxkVHlwZTxGaWVsZFR5cGVDb25maWc8RGF0ZXRpbWVQcm9wcz4+IHtcbiAgQFZpZXdDaGlsZChJb25EYXRldGltZSkgZGF0ZXRpbWUhOiBJb25EYXRldGltZTtcbiAgaXNPcGVuID0gZmFsc2U7XG5cbiAgb3ZlcnJpZGUgZGVmYXVsdE9wdGlvbnMgPSB7XG4gICAgcHJvcHM6IHtcbiAgICAgIHByZXNlbnRhdGlvbjogJ21vbnRoLXllYXInIGFzIGNvbnN0LFxuICAgIH0sXG4gIH07XG5cbiAgZGlzcGxheUZvcm1hdCgpIHtcbiAgICBpZiAodGhpcy5wcm9wcy5kaXNwbGF5Rm9ybWF0KSB7XG4gICAgICByZXR1cm4gdGhpcy5wcm9wcy5kaXNwbGF5Rm9ybWF0O1xuICAgIH1cblxuICAgIHN3aXRjaCAodGhpcy5wcm9wcy5wcmVzZW50YXRpb24pIHtcbiAgICAgIGNhc2UgJ2RhdGUtdGltZSc6XG4gICAgICBjYXNlICd0aW1lLWRhdGUnOlxuICAgICAgICByZXR1cm4gJ3Nob3J0JztcbiAgICAgIGNhc2UgJ3RpbWUnOlxuICAgICAgICByZXR1cm4gJ3Nob3J0VGltZSc7XG4gICAgICBjYXNlICdtb250aCc6XG4gICAgICAgIHJldHVybiAnTU1NTSc7XG4gICAgICBjYXNlICdtb250aC15ZWFyJzpcbiAgICAgICAgcmV0dXJuICdNTU1NLCB5JztcbiAgICAgIGNhc2UgJ3llYXInOlxuICAgICAgICByZXR1cm4gJ3knO1xuICAgICAgY2FzZSAnZGF0ZSc6XG4gICAgICAgIHJldHVybiAnbWVkaXVtRGF0ZSc7XG4gICAgfVxuICB9XG5cbiAgY29uZmlybSgpIHtcbiAgICB0aGlzLmRhdGV0aW1lPy5jb25maXJtKCk7XG4gICAgdGhpcy5jbG9zZSgpO1xuICB9XG5cbiAgcmVzZXQoKSB7XG4gICAgdGhpcy5kYXRldGltZT8ucmVzZXQoKTtcbiAgICB0aGlzLmNsb3NlKCk7XG4gIH1cblxuICBjbG9zZSgpIHtcbiAgICB0aGlzLmlzT3BlbiA9IGZhbHNlO1xuICAgIHRoaXMuZm9ybUNvbnRyb2wubWFya0FzVG91Y2hlZCgpO1xuICB9XG59XG4iXX0=