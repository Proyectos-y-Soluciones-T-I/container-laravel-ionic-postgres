import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
import * as i1 from "@ionic/angular";
import * as i2 from "@ngx-formly/core";
import * as i3 from "@angular/forms";
import * as i4 from "@ngx-formly/ionic/form-field";
import * as i5 from "@angular/common";
import * as i6 from "@ngx-formly/core/select";
export class FormlyFieldRadio extends FieldType {
}
FormlyFieldRadio.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: FormlyFieldRadio, deps: null, target: i0.ɵɵFactoryTarget.Component });
FormlyFieldRadio.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.3.12", type: FormlyFieldRadio, selector: "formly-field-ion-radio", usesInheritance: true, ngImport: i0, template: `
    <ion-list>
      <ion-radio-group [formControl]="formControl" [ionFormlyAttributes]="field">
        <ion-list-header>{{ props.label }}</ion-list-header>
        <ion-item
          *ngFor="let option of props.options | formlySelectOptions : field | async"
          [disabled]="option.disabled || formControl.disabled"
        >
          <ion-label>{{ option.label }}</ion-label>
          <ion-radio [value]="option.value"></ion-radio>
        </ion-item>
      </ion-radio-group>
    </ion-list>
    <ion-item lines="none" *ngIf="showError">
      <ion-label>
        <ion-text color="danger">
          <p>
            <formly-validation-message [field]="field"></formly-validation-message>
          </p>
        </ion-text>
      </ion-label>
    </ion-item>
  `, isInline: true, components: [{ type: i1.IonList, selector: "ion-list", inputs: ["inset", "lines", "mode"] }, { type: i1.IonRadioGroup, selector: "ion-radio-group", inputs: ["allowEmptySelection", "name", "value"] }, { type: i1.IonListHeader, selector: "ion-list-header", inputs: ["color", "lines", "mode"] }, { type: i1.IonItem, selector: "ion-item", inputs: ["button", "color", "counter", "counterFormatter", "detail", "detailIcon", "disabled", "download", "fill", "href", "lines", "mode", "rel", "routerAnimation", "routerDirection", "shape", "target", "type"] }, { type: i1.IonLabel, selector: "ion-label", inputs: ["color", "mode", "position"] }, { type: i1.IonRadio, selector: "ion-radio", inputs: ["color", "disabled", "mode", "name", "value"] }, { type: i1.IonText, selector: "ion-text", inputs: ["color", "mode"] }, { type: i2.ɵFormlyValidationMessage, selector: "formly-validation-message", inputs: ["field"] }], directives: [{ type: i1.SelectValueAccessor, selector: "ion-range, ion-select, ion-radio-group, ion-segment, ion-datetime" }, { type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { type: i4.ɵIonFormlyAttributes, selector: "[ionFormlyAttributes]", inputs: ["ionFormlyAttributes"] }, { type: i5.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i1.RadioValueAccessor, selector: "ion-radio" }, { type: i5.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], pipes: { "async": i5.AsyncPipe, "formlySelectOptions": i6.FormlySelectOptionsPipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: FormlyFieldRadio, decorators: [{
            type: Component,
            args: [{
                    selector: 'formly-field-ion-radio',
                    template: `
    <ion-list>
      <ion-radio-group [formControl]="formControl" [ionFormlyAttributes]="field">
        <ion-list-header>{{ props.label }}</ion-list-header>
        <ion-item
          *ngFor="let option of props.options | formlySelectOptions : field | async"
          [disabled]="option.disabled || formControl.disabled"
        >
          <ion-label>{{ option.label }}</ion-label>
          <ion-radio [value]="option.value"></ion-radio>
        </ion-item>
      </ion-radio-group>
    </ion-list>
    <ion-item lines="none" *ngIf="showError">
      <ion-label>
        <ion-text color="danger">
          <p>
            <formly-validation-message [field]="field"></formly-validation-message>
          </p>
        </ion-text>
      </ion-label>
    </ion-item>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmFkaW8udHlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy91aS9pb25pYy9yYWRpby9zcmMvcmFkaW8udHlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLHVCQUF1QixFQUFRLE1BQU0sZUFBZSxDQUFDO0FBQ3pFLE9BQU8sRUFBRSxTQUFTLEVBQXNDLE1BQU0sa0JBQWtCLENBQUM7Ozs7Ozs7O0FBb0NqRixNQUFNLE9BQU8sZ0JBQWlCLFNBQVEsU0FBc0M7OzhHQUEvRCxnQkFBZ0I7a0dBQWhCLGdCQUFnQixxRkF6QmpCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBc0JUOzRGQUdVLGdCQUFnQjtrQkEzQjVCLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLHdCQUF3QjtvQkFDbEMsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBc0JUO29CQUNELGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2lCQUNoRCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIFR5cGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZpZWxkVHlwZSwgRmllbGRUeXBlQ29uZmlnLCBGb3JtbHlGaWVsZENvbmZpZyB9IGZyb20gJ0BuZ3gtZm9ybWx5L2NvcmUnO1xuaW1wb3J0IHsgRm9ybWx5RmllbGRQcm9wcyB9IGZyb20gJ0BuZ3gtZm9ybWx5L2lvbmljL2Zvcm0tZmllbGQnO1xuXG5pbnRlcmZhY2UgUmFkaW9Qcm9wcyBleHRlbmRzIEZvcm1seUZpZWxkUHJvcHMge31cblxuZXhwb3J0IGludGVyZmFjZSBGb3JtbHlSYWRpb0ZpZWxkQ29uZmlnIGV4dGVuZHMgRm9ybWx5RmllbGRDb25maWc8UmFkaW9Qcm9wcz4ge1xuICB0eXBlOiAncmFkaW8nIHwgVHlwZTxGb3JtbHlGaWVsZFJhZGlvPjtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnZm9ybWx5LWZpZWxkLWlvbi1yYWRpbycsXG4gIHRlbXBsYXRlOiBgXG4gICAgPGlvbi1saXN0PlxuICAgICAgPGlvbi1yYWRpby1ncm91cCBbZm9ybUNvbnRyb2xdPVwiZm9ybUNvbnRyb2xcIiBbaW9uRm9ybWx5QXR0cmlidXRlc109XCJmaWVsZFwiPlxuICAgICAgICA8aW9uLWxpc3QtaGVhZGVyPnt7IHByb3BzLmxhYmVsIH19PC9pb24tbGlzdC1oZWFkZXI+XG4gICAgICAgIDxpb24taXRlbVxuICAgICAgICAgICpuZ0Zvcj1cImxldCBvcHRpb24gb2YgcHJvcHMub3B0aW9ucyB8IGZvcm1seVNlbGVjdE9wdGlvbnMgOiBmaWVsZCB8IGFzeW5jXCJcbiAgICAgICAgICBbZGlzYWJsZWRdPVwib3B0aW9uLmRpc2FibGVkIHx8IGZvcm1Db250cm9sLmRpc2FibGVkXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxpb24tbGFiZWw+e3sgb3B0aW9uLmxhYmVsIH19PC9pb24tbGFiZWw+XG4gICAgICAgICAgPGlvbi1yYWRpbyBbdmFsdWVdPVwib3B0aW9uLnZhbHVlXCI+PC9pb24tcmFkaW8+XG4gICAgICAgIDwvaW9uLWl0ZW0+XG4gICAgICA8L2lvbi1yYWRpby1ncm91cD5cbiAgICA8L2lvbi1saXN0PlxuICAgIDxpb24taXRlbSBsaW5lcz1cIm5vbmVcIiAqbmdJZj1cInNob3dFcnJvclwiPlxuICAgICAgPGlvbi1sYWJlbD5cbiAgICAgICAgPGlvbi10ZXh0IGNvbG9yPVwiZGFuZ2VyXCI+XG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICA8Zm9ybWx5LXZhbGlkYXRpb24tbWVzc2FnZSBbZmllbGRdPVwiZmllbGRcIj48L2Zvcm1seS12YWxpZGF0aW9uLW1lc3NhZ2U+XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2lvbi10ZXh0PlxuICAgICAgPC9pb24tbGFiZWw+XG4gICAgPC9pb24taXRlbT5cbiAgYCxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIEZvcm1seUZpZWxkUmFkaW8gZXh0ZW5kcyBGaWVsZFR5cGU8RmllbGRUeXBlQ29uZmlnPFJhZGlvUHJvcHM+PiB7fVxuIl19