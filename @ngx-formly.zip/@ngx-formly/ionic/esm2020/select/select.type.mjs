import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
import * as i1 from "@ionic/angular";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "@ngx-formly/ionic/form-field";
import * as i5 from "@ngx-formly/core/select";
export class FormlyFieldSelect extends FieldType {
    constructor() {
        super(...arguments);
        this.defaultOptions = {
            props: {
                compareWith(o1, o2) {
                    return o1 === o2;
                },
            },
        };
    }
}
FormlyFieldSelect.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: FormlyFieldSelect, deps: null, target: i0.ɵɵFactoryTarget.Component });
FormlyFieldSelect.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.3.12", type: FormlyFieldSelect, selector: "formly-field-ion-select", usesInheritance: true, ngImport: i0, template: `
    <!-- ng-container used as a workaround for https://github.com/ionic-team/ionic/issues/19324 -->
    <ng-container *ngIf="props.options | formlySelectOptions : field | async; let selectOptions">
      <ion-select
        [style.align-self]="props.labelPosition === 'floating' ? 'stretch' : ''"
        [style.max-width.%]="props.labelPosition === 'floating' ? 100 : ''"
        [formControl]="formControl"
        [compareWith]="props.compareWith"
        [ionFormlyAttributes]="field"
        [multiple]="props.multiple"
        [interface]="props.interface"
        [okText]="props.okText"
        [cancelText]="props.cancelText"
      >
        <ion-select-option *ngFor="let option of selectOptions" [value]="option.value" [disabled]="option.disabled">
          {{ option.label }}
        </ion-select-option>
      </ion-select>
    </ng-container>
  `, isInline: true, styles: [":host{display:inherit}\n"], components: [{ type: i1.IonSelect, selector: "ion-select", inputs: ["cancelText", "compareWith", "disabled", "interface", "interfaceOptions", "mode", "multiple", "name", "okText", "placeholder", "selectedText", "value"] }, { type: i1.IonSelectOption, selector: "ion-select-option", inputs: ["disabled", "value"] }], directives: [{ type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1.SelectValueAccessor, selector: "ion-range, ion-select, ion-radio-group, ion-segment, ion-datetime" }, { type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { type: i4.ɵIonFormlyAttributes, selector: "[ionFormlyAttributes]", inputs: ["ionFormlyAttributes"] }, { type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }], pipes: { "async": i2.AsyncPipe, "formlySelectOptions": i5.FormlySelectOptionsPipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.3.12", ngImport: i0, type: FormlyFieldSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'formly-field-ion-select',
                    template: `
    <!-- ng-container used as a workaround for https://github.com/ionic-team/ionic/issues/19324 -->
    <ng-container *ngIf="props.options | formlySelectOptions : field | async; let selectOptions">
      <ion-select
        [style.align-self]="props.labelPosition === 'floating' ? 'stretch' : ''"
        [style.max-width.%]="props.labelPosition === 'floating' ? 100 : ''"
        [formControl]="formControl"
        [compareWith]="props.compareWith"
        [ionFormlyAttributes]="field"
        [multiple]="props.multiple"
        [interface]="props.interface"
        [okText]="props.okText"
        [cancelText]="props.cancelText"
      >
        <ion-select-option *ngFor="let option of selectOptions" [value]="option.value" [disabled]="option.disabled">
          {{ option.label }}
        </ion-select-option>
      </ion-select>
    </ng-container>
  `,
                    styles: [':host { display: inherit; }'],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VsZWN0LnR5cGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvdWkvaW9uaWMvc2VsZWN0L3NyYy9zZWxlY3QudHlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLHVCQUF1QixFQUFRLE1BQU0sZUFBZSxDQUFDO0FBQ3pFLE9BQU8sRUFBRSxTQUFTLEVBQXNDLE1BQU0sa0JBQWtCLENBQUM7Ozs7Ozs7QUF5Q2pGLE1BQU0sT0FBTyxpQkFBa0IsU0FBUSxTQUF1QztJQXpCOUU7O1FBMEJXLG1CQUFjLEdBQUc7WUFDeEIsS0FBSyxFQUFFO2dCQUNMLFdBQVcsQ0FBQyxFQUFPLEVBQUUsRUFBTztvQkFDMUIsT0FBTyxFQUFFLEtBQUssRUFBRSxDQUFDO2dCQUNuQixDQUFDO2FBQ0Y7U0FDRixDQUFDO0tBQ0g7OytHQVJZLGlCQUFpQjttR0FBakIsaUJBQWlCLHNGQXZCbEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FtQlQ7NEZBSVUsaUJBQWlCO2tCQXpCN0IsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUseUJBQXlCO29CQUNuQyxRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FtQlQ7b0JBQ0QsTUFBTSxFQUFFLENBQUMsNkJBQTZCLENBQUM7b0JBQ3ZDLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2lCQUNoRCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIFR5cGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZpZWxkVHlwZSwgRmllbGRUeXBlQ29uZmlnLCBGb3JtbHlGaWVsZENvbmZpZyB9IGZyb20gJ0BuZ3gtZm9ybWx5L2NvcmUnO1xuaW1wb3J0IHsgRm9ybWx5RmllbGRQcm9wcyB9IGZyb20gJ0BuZ3gtZm9ybWx5L2lvbmljL2Zvcm0tZmllbGQnO1xuaW1wb3J0IHsgRm9ybWx5RmllbGRTZWxlY3RQcm9wcyB9IGZyb20gJ0BuZ3gtZm9ybWx5L2NvcmUvc2VsZWN0JztcblxuaW50ZXJmYWNlIFNlbGVjdFByb3BzIGV4dGVuZHMgRm9ybWx5RmllbGRQcm9wcywgRm9ybWx5RmllbGRTZWxlY3RQcm9wcyB7XG4gIGNvbXBhcmVXaXRoPzogKChjdXJyZW50VmFsdWU6IGFueSwgY29tcGFyZVZhbHVlOiBhbnkpID0+IGJvb2xlYW4pIHwgbnVsbCB8IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgbXVsdGlwbGU/OiBib29sZWFuO1xuICBpbnRlcmZhY2U/OiAnYWN0aW9uLXNoZWV0JyB8ICdhbGVydCcgfCAncG9wb3Zlcic7XG4gIG9rVGV4dD86IHN0cmluZztcbiAgY2FuY2VsVGV4dD86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBGb3JtbHlTZWxlY3RGaWVsZENvbmZpZyBleHRlbmRzIEZvcm1seUZpZWxkQ29uZmlnPFNlbGVjdFByb3BzPiB7XG4gIHR5cGU6ICdzZWxlY3QnIHwgVHlwZTxGb3JtbHlGaWVsZFNlbGVjdD47XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2Zvcm1seS1maWVsZC1pb24tc2VsZWN0JyxcbiAgdGVtcGxhdGU6IGBcbiAgICA8IS0tIG5nLWNvbnRhaW5lciB1c2VkIGFzIGEgd29ya2Fyb3VuZCBmb3IgaHR0cHM6Ly9naXRodWIuY29tL2lvbmljLXRlYW0vaW9uaWMvaXNzdWVzLzE5MzI0IC0tPlxuICAgIDxuZy1jb250YWluZXIgKm5nSWY9XCJwcm9wcy5vcHRpb25zIHwgZm9ybWx5U2VsZWN0T3B0aW9ucyA6IGZpZWxkIHwgYXN5bmM7IGxldCBzZWxlY3RPcHRpb25zXCI+XG4gICAgICA8aW9uLXNlbGVjdFxuICAgICAgICBbc3R5bGUuYWxpZ24tc2VsZl09XCJwcm9wcy5sYWJlbFBvc2l0aW9uID09PSAnZmxvYXRpbmcnID8gJ3N0cmV0Y2gnIDogJydcIlxuICAgICAgICBbc3R5bGUubWF4LXdpZHRoLiVdPVwicHJvcHMubGFiZWxQb3NpdGlvbiA9PT0gJ2Zsb2F0aW5nJyA/IDEwMCA6ICcnXCJcbiAgICAgICAgW2Zvcm1Db250cm9sXT1cImZvcm1Db250cm9sXCJcbiAgICAgICAgW2NvbXBhcmVXaXRoXT1cInByb3BzLmNvbXBhcmVXaXRoXCJcbiAgICAgICAgW2lvbkZvcm1seUF0dHJpYnV0ZXNdPVwiZmllbGRcIlxuICAgICAgICBbbXVsdGlwbGVdPVwicHJvcHMubXVsdGlwbGVcIlxuICAgICAgICBbaW50ZXJmYWNlXT1cInByb3BzLmludGVyZmFjZVwiXG4gICAgICAgIFtva1RleHRdPVwicHJvcHMub2tUZXh0XCJcbiAgICAgICAgW2NhbmNlbFRleHRdPVwicHJvcHMuY2FuY2VsVGV4dFwiXG4gICAgICA+XG4gICAgICAgIDxpb24tc2VsZWN0LW9wdGlvbiAqbmdGb3I9XCJsZXQgb3B0aW9uIG9mIHNlbGVjdE9wdGlvbnNcIiBbdmFsdWVdPVwib3B0aW9uLnZhbHVlXCIgW2Rpc2FibGVkXT1cIm9wdGlvbi5kaXNhYmxlZFwiPlxuICAgICAgICAgIHt7IG9wdGlvbi5sYWJlbCB9fVxuICAgICAgICA8L2lvbi1zZWxlY3Qtb3B0aW9uPlxuICAgICAgPC9pb24tc2VsZWN0PlxuICAgIDwvbmctY29udGFpbmVyPlxuICBgLFxuICBzdHlsZXM6IFsnOmhvc3QgeyBkaXNwbGF5OiBpbmhlcml0OyB9J10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBGb3JtbHlGaWVsZFNlbGVjdCBleHRlbmRzIEZpZWxkVHlwZTxGaWVsZFR5cGVDb25maWc8U2VsZWN0UHJvcHM+PiB7XG4gIG92ZXJyaWRlIGRlZmF1bHRPcHRpb25zID0ge1xuICAgIHByb3BzOiB7XG4gICAgICBjb21wYXJlV2l0aChvMTogYW55LCBvMjogYW55KSB7XG4gICAgICAgIHJldHVybiBvMSA9PT0gbzI7XG4gICAgICB9LFxuICAgIH0sXG4gIH07XG59XG4iXX0=